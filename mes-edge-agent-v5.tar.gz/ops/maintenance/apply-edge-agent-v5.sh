#!/usr/bin/env bash
# One-off patch for edge-agent-v5: parts produced while the agent was not
# running (or could not reach the PLC) are booked afterwards - for gaps up to
# a per-node limit (default 10 minutes); the instance lease is released on a
# clean shutdown; the onboarding unit gets a persistent state directory.
# Run from the repo root on node-dc after extracting the archive, review, test,
# commit, then cut the release tag. Delete this script after applying.
set -euo pipefail

A=packages/edge-agent
need=(
  "$A/src/index.ts" "$A/src/config.ts" "$A/src/catchup.ts" "$A/src/counter-baseline.ts"
  "$A/src/signal-sources/ModbusSignalSource.ts" "$A/src/signal-sources/OpcUaSignalSource.ts"
  "$A/python/s7_bridge.py" "$A/python/catchup.py" ops/onboarding/install-on-node.sh
)
for f in "${need[@]}"; do
  [[ -f $f ]] || { echo "Missing $f (run from the repo root, after extracting the archive)" >&2; exit 1; }
done
grep -q counterBaselineFor "$A/src/index.ts" && { echo "Already applied" >&2; exit 1; }

node - <<'NODE'
const fs = require("node:fs");
const A = "packages/edge-agent";
const files = {};
const read = (f) => (files[f] ??= fs.readFileSync(f, "utf8"));
let failed = false;

// Every anchor must match exactly once; nothing is written otherwise.
function edit(f, anchor, replacement) {
  const s = read(f);
  const n = s.split(anchor).length - 1;
  if (n !== 1) { console.error(`${f}: anchor matched ${n} times (expected 1):\n${anchor}\n`); failed = true; return; }
  files[f] = s.replace(anchor, () => replacement);
}

// ---------------------------------------------------------------- config.ts
const CFG = `${A}/src/config.ts`;
edit(CFG, "export const config = {\n", `function catchupMinutesFromEnv(raw: string | undefined): number {
  if (raw === undefined) return 10;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 0 || n > 1440) throw new Error("CATCHUP_MAX_MINUTES must be an integer between 0 and 1440");
  return n;
}

export const config = {
`);
edit(CFG, `  bufferFilePath: process.env.BUFFER_FILE_PATH ?? "/tmp/mes-edge-agent-buffer.ndjson",\n`,
`  bufferFilePath: process.env.BUFFER_FILE_PATH ?? "/tmp/mes-edge-agent-buffer.ndjson",
  // Where the last seen PLC counter values are kept (survives restarts).
  counterStateDir: process.env.COUNTER_STATE_DIR ?? path.dirname(process.env.BUFFER_FILE_PATH ?? "/tmp/mes-edge-agent-buffer.ndjson"),
  // Longest gap (minutes) whose parts are still booked afterwards; 0 = off.
  // In registry mode the backend's per-node setting overrides this value.
  catchupMaxMinutes: catchupMinutesFromEnv(process.env.CATCHUP_MAX_MINUTES),
`);

// ------------------------------------------------- Modbus / OPC-UA sources
const seed = (indent) => `${indent}if (
${indent}  this.options.counterBaseline &&
${indent}  this.lastGoodCount === null &&
${indent}  this.lastScrapCount === null &&
${indent}  typeof goodCount === "number" &&
${indent}  typeof scrapCount === "number"
${indent}) {
${indent}  // First reading after a start or a lost connection: book the parts made while not observed.
${indent}  const seeded = this.options.counterBaseline.onFirstRead(goodCount, scrapCount);
${indent}  for (let i = 0; i < seeded.good; i++) onReading({ kind: "production_count", result: "good" });
${indent}  for (let i = 0; i < seeded.scrap; i++) onReading({ kind: "production_count", result: "scrap" });
${indent}}

`;
const remember = (indent) => `${indent}if (typeof goodCount === "number" && typeof scrapCount === "number") {
${indent}  this.options.counterBaseline?.onRead(goodCount, scrapCount);
${indent}}

`;
const forget = (indent) => `${indent}if (this.options.counterBaseline) {
${indent}  // Re-baseline after the connection is back (see CounterBaseline.onFirstRead).
${indent}  this.lastGoodCount = null;
${indent}  this.lastScrapCount = null;
${indent}}
`;
const IMPORT = 'import type { CounterBaseline } from "../counter-baseline.js";\n\n';

const MOD = `${A}/src/signal-sources/ModbusSignalSource.ts`;
edit(MOD, "export interface ModbusSignalSourceOptions {\n", IMPORT + "export interface ModbusSignalSourceOptions {\n");
edit(MOD, "  statusRegister?: number;\n  pollIntervalMs?: number;\n}", "  statusRegister?: number;\n  pollIntervalMs?: number;\n  /** Books parts produced while the agent or the PLC link was down (see counter-baseline.ts). */\n  counterBaseline?: CounterBaseline;\n}");
edit(MOD, '      if (typeof goodCount === "number") {\n', seed("      ") + '      if (typeof goodCount === "number") {\n');
edit(MOD, '      if (typeof statusCode === "number" && statusCode !== this.lastStatus) {\n', remember("      ") + '      if (typeof statusCode === "number" && statusCode !== this.lastStatus) {\n');
edit(MOD, "        this.reportedDown = true;\n        this.lastStatus = null;\n", "        this.reportedDown = true;\n        this.lastStatus = null;\n" + forget("        "));

const OPC = `${A}/src/signal-sources/OpcUaSignalSource.ts`;
edit(OPC, "export interface OpcUaSignalSourceOptions {\n", IMPORT + "export interface OpcUaSignalSourceOptions {\n");
edit(OPC, "  statusNodeId: string;\n  pollIntervalMs?: number;\n}", "  statusNodeId: string;\n  pollIntervalMs?: number;\n  /** Books parts produced while the agent or the PLC link was down (see counter-baseline.ts). */\n  counterBaseline?: CounterBaseline;\n}");
edit(OPC, '      if (typeof goodCount === "number") {\n', seed("      ") + '      if (typeof goodCount === "number") {\n');
edit(OPC, '      if (typeof status === "string" && status !== this.lastStatus) {\n', remember("      ") + '      if (typeof status === "string" && status !== this.lastStatus) {\n');
edit(OPC, "        this.reportedDown = true;\n        this.lastStatus = null;\n", "        this.reportedDown = true;\n        this.lastStatus = null;\n" + forget("        "));

// ----------------------------------------------------------------- index.ts
const IDX = `${A}/src/index.ts`;
{
  const lines = read(IDX).split("\n");
  let last = -1;
  lines.forEach((l, i) => { if (/^import .* from ".*";\s*$/.test(l)) last = i; });
  if (last < 0) { console.error("index.ts: no single-line import found"); failed = true; }
  else {
    lines.splice(last + 1, 0, 'import { join as joinPath } from "node:path";', 'import { CounterBaseline } from "./counter-baseline.js";');
    files[IDX] = lines.join("\n");
  }
}
edit(IDX, "function buildInnerSignalSource(): SignalSource {\n", `// Per-node settings. In registry mode the backend delivers them on claim; the
// environment value is the fallback (legacy mode, older backends).
const nodeSettings = { catchupMaxMinutes: config.catchupMaxMinutes };

function counterStateFile(machineId: string): string {
  return joinPath(config.counterStateDir, \`counters.\${machineId.replace(/[^A-Za-z0-9._-]/g, "_")}.json\`);
}

function counterBaselineFor(machineId: string): CounterBaseline {
  return new CounterBaseline({
    machineId,
    filePath: counterStateFile(machineId),
    maxAgeMs: nodeSettings.catchupMaxMinutes * 60_000,
    log: { info: (obj, msg) => log.info(obj, msg), warn: (obj, msg) => log.warn(obj, msg) },
  });
}

function s7CatchupEnv(machineId: string): Record<string, string> {
  return {
    COUNTER_STATE_FILE: counterStateFile(machineId),
    CATCHUP_MAX_AGE_SECONDS: String(nodeSettings.catchupMaxMinutes * 60),
  };
}

function buildInnerSignalSource(): SignalSource {
`);
// legacy builders (machine id = config.machineId)
edit(IDX, "          ...(config.s7.pollIntervalMs ? { POLL_INTERVAL_MS: config.s7.pollIntervalMs } : {}),\n",
  "          ...(config.s7.pollIntervalMs ? { POLL_INTERVAL_MS: config.s7.pollIntervalMs } : {}),\n          ...s7CatchupEnv(config.machineId),\n");
edit(IDX, "        pollIntervalMs: config.opcua.pollIntervalMs ? parseInt(config.opcua.pollIntervalMs, 10) : undefined,\n",
  "        pollIntervalMs: config.opcua.pollIntervalMs ? parseInt(config.opcua.pollIntervalMs, 10) : undefined,\n        counterBaseline: counterBaselineFor(config.machineId),\n");
edit(IDX, "        pollIntervalMs: config.modbus.pollIntervalMs ? parseInt(config.modbus.pollIntervalMs, 10) : undefined,\n",
  "        pollIntervalMs: config.modbus.pollIntervalMs ? parseInt(config.modbus.pollIntervalMs, 10) : undefined,\n        counterBaseline: counterBaselineFor(config.machineId),\n");
// registry builders
edit(IDX, "          ...(cc.plcPort !== undefined ? { PLC_PORT: String(cc.plcPort) } : {}),\n",
  "          ...(cc.plcPort !== undefined ? { PLC_PORT: String(cc.plcPort) } : {}),\n          ...s7CatchupEnv(ch.machineId),\n");
edit(IDX, "        statusNodeId: cc.statusNodeId,\n      });\n",
  "        statusNodeId: cc.statusNodeId,\n        counterBaseline: counterBaselineFor(ch.machineId),\n      });\n");
edit(IDX, "        statusRegister: cc.statusRegister,\n      });\n",
  "        statusRegister: cc.statusRegister,\n        counterBaseline: counterBaselineFor(ch.machineId),\n      });\n");
// claim: settings
edit(IDX, "async function claimEdgeNode(token: string): Promise<{ sessionId: string; channels: ChannelConfig[] }> {",
  "async function claimEdgeNode(\n  token: string,\n): Promise<{ sessionId: string; channels: ChannelConfig[]; settings: { catchupMaxMinutes: number } }> {");
edit(IDX, "  const body = (await res.json()) as {\n    sessionId: string;\n",
  "  const body = (await res.json()) as {\n    sessionId: string;\n    settings?: { catchupMaxMinutes?: number };\n");
edit(IDX, "  return {\n    sessionId: body.sessionId,\n", `  const wanted = body.settings?.catchupMaxMinutes;
  return {
    sessionId: body.sessionId,
    settings: {
      catchupMaxMinutes:
        typeof wanted === "number" && Number.isInteger(wanted) && wanted >= 0 && wanted <= 1440 ? wanted : config.catchupMaxMinutes,
    },
`);
// release on shutdown + apply settings
edit(IDX, "async function runRegistryMode(token: string): Promise<void> {\n", `/** Gives the instance lease back on a clean shutdown, so the next start does not wait for the 90 s heartbeat timeout. */
async function releaseSession(token: string, sessionId: string): Promise<void> {
  try {
    const res = await fetch(\`\${config.backendHttpUrl}/api/edge-nodes/release\`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, sessionId }),
      signal: AbortSignal.timeout(3000),
    });
    if (!res.ok) log.warn({ status: res.status }, "could not release the edge node session");
  } catch (err) {
    log.warn({ err }, "could not release the edge node session (the next start may wait up to 90 s)");
  }
}

async function runRegistryMode(token: string): Promise<void> {
`);
edit(IDX, "  const { sessionId, channels } = await claimEdgeNode(token);\n  log.info({ channelCount: channels.length }, \"claimed edge node, starting channels\");\n",
  "  const { sessionId, channels, settings } = await claimEdgeNode(token);\n  nodeSettings.catchupMaxMinutes = settings.catchupMaxMinutes;\n  log.info({ channelCount: channels.length, catchupMaxMinutes: settings.catchupMaxMinutes }, \"claimed edge node, starting channels\");\n");
edit(IDX, "    clearInterval(heartbeatTimer);\n    client.end(false, {}, () => process.exit(0));\n",
  "    clearInterval(heartbeatTimer);\n    void releaseSession(token, sessionId).finally(() => client.end(false, {}, () => process.exit(0)));\n");

// ------------------------------------------------------------- s7_bridge.py
const PY = `${A}/python/s7_bridge.py`;
edit(PY, "from snap7.util import get_bool, get_dint\n",
  "from snap7.util import get_bool, get_dint\n\nfrom catchup import describe_plan, load_counter_state, plan_catchup, save_counter_state\n");
edit(PY, 'RECONNECT_DELAY_SECONDS = float(os.environ.get("RECONNECT_DELAY_SECONDS", 3.0))\n',
  `RECONNECT_DELAY_SECONDS = float(os.environ.get("RECONNECT_DELAY_SECONDS", 3.0))
# Catch-up of parts produced while this bridge could not see the PLC (see catchup.py).
COUNTER_STATE_FILE = os.environ.get("COUNTER_STATE_FILE", "")
CATCHUP_MAX_AGE_SECONDS = float(os.environ.get("CATCHUP_MAX_AGE_SECONDS", 600))
COUNTER_SAVE_EVERY_SECONDS = 5.0
`);
edit(PY, "    first_poll = True\n    down_reported = False\n",
  `    first_poll = True
    down_reported = False
    # Last observed counters, in memory and (if COUNTER_STATE_FILE is set) on disk.
    last_seen = load_counter_state(COUNTER_STATE_FILE)
    saved = None
    last_saved_at = 0.0
    last_save_warning_at = 0.0
`);
edit(PY, `                    emit({"kind": "machine_status", "status": "running" if current["running"] else "down"})\n                    first_poll = False\n`,
  `                    emit({"kind": "machine_status", "status": "running" if current["running"] else "down"})
                    # Book the parts made while we could not see the PLC (within the allowed gap).
                    plan = plan_catchup(last_seen, current, int(time.time() * 1000), int(CATCHUP_MAX_AGE_SECONDS * 1000))
                    for _ in range(plan["emit"]["good"]):
                        emit({"kind": "production_count", "result": "good"})
                    for _ in range(plan["emit"]["scrap"]):
                        emit({"kind": "production_count", "result": "scrap"})
                    message = describe_plan(plan)
                    if message:
                        print(f"[s7-bridge] {message}", file=sys.stderr, flush=True)
                    first_poll = False
`);
edit(PY, "                previous = current\n                time.sleep(POLL_INTERVAL_SECONDS)\n",
  `                previous = current
                last_seen = {"good": current["good"], "scrap": current["scrap"], "seenAtMs": int(time.time() * 1000)}
                if COUNTER_STATE_FILE:
                    changed = saved != (current["good"], current["scrap"])
                    if changed or time.monotonic() - last_saved_at >= COUNTER_SAVE_EVERY_SECONDS:
                        try:
                            save_counter_state(COUNTER_STATE_FILE, current["good"], current["scrap"], last_seen["seenAtMs"])
                            saved = (current["good"], current["scrap"])
                            last_saved_at = time.monotonic()
                        except OSError as save_exc:
                            # Never let a full disk stop the counting itself.
                            if time.monotonic() - last_save_warning_at >= 60:
                                last_save_warning_at = time.monotonic()
                                print(f"[s7-bridge] could not save counter state: {save_exc}", file=sys.stderr, flush=True)
                time.sleep(POLL_INTERVAL_SECONDS)
`);

// ------------------------------------------------------------ onboarding
const ONB = "ops/onboarding/install-on-node.sh";
edit(ONB, "Environment=NODE_EXTRA_CA_CERTS=/etc/ssl/mes-ca.crt\nRestart=on-failure\n",
  "Environment=NODE_EXTRA_CA_CERTS=/etc/ssl/mes-ca.crt\n# Persistent buffer and counter state (survive reboots; /tmp does not).\nStateDirectory=mes-edge\nEnvironment=BUFFER_FILE_PATH=/var/lib/mes-edge/buffer.ndjson\nRestart=on-failure\n");

if (failed) { console.error("No file was changed."); process.exit(1); }
for (const [f, s] of Object.entries(files)) fs.writeFileSync(f, s);
console.log("Patched " + Object.keys(files).length + " files.");
NODE

# release notes (appended once)
R=docs/EDGE_AGENT_RELEASES.md
if [[ -f $R ]] && ! grep -q 'edge-agent-v5' "$R"; then
cat >> "$R" <<'DOC'

- **edge-agent-v5** (Oct 2026) — parts produced while the agent was not running,
  or could not reach the PLC, are booked afterwards, but only for gaps up to
  `catchupMaxMinutes` (default 10; per edge node, delivered by the backend on
  claim; `CATCHUP_MAX_MINUTES` is the fallback; 0 switches it off). Longer gaps
  are dropped with a warning in the log (event timestamps are the time of
  booking, so a long gap would land in the wrong hour and shift). The last seen
  counters are kept in `COUNTER_STATE_DIR` (default: the buffer's directory).
  On SIGTERM the agent releases its instance lease (`POST /api/edge-nodes/release`),
  so a clean restart no longer leaves a ~70 s gap; deploy the backend first.
  The onboarding script now generates units with `StateDirectory=mes-edge` and
  `BUFFER_FILE_PATH=/var/lib/mes-edge/buffer.ndjson`.
DOC
fi
echo "Patched. Review with: git --no-pager diff --stat"
